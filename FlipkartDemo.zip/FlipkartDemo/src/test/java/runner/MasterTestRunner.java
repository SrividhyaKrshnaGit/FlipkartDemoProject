package runner;

import java.io.IOException;

import org.testng.annotations.Test;
import test.BaseTest;
import test.LoginTest;
import test.ProductsearchTest;
import test.ProducttocartTest;


public class MasterTestRunner extends BaseTest {

	@Test(priority = 0)

	public void loginTest() throws IOException, InterruptedException {

		LoginTest login = new LoginTest();
		login.applogin();
	}

	@Test(priority = 1)

	public void productSearchTest() throws IOException, InterruptedException {

		ProductsearchTest productsearch = new ProductsearchTest();
		productsearch.productSearch();

	}

	@Test(priority = 2)

	public void ProducttocartTest() throws IOException, InterruptedException {

		ProducttocartTest producttocart = new ProducttocartTest();
		producttocart.addToCart();

	}
}