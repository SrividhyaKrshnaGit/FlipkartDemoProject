package screen;

import test.BaseTest;

public class LoginScreen extends BaseTest{
	
	public static final String Burger_Menu ="//*[@content-desc='Open Drawer']";
	public static final String My_Account ="//*[@text='My Account']";
	public static final String My_Account_EmailLogin="//*[@text='Use Email-ID']";
	public static final String My_Account_Emailfield ="//*[@text='Email ID']";
	public static final String My_Account_Continue ="//*[@text='Continue']";
	public static final String My_Account_Passwordfield ="//*[@text='Password']";
	public static final String My_Account_Back ="//*[@content-desc='Back Button']";

	
	
	

}
