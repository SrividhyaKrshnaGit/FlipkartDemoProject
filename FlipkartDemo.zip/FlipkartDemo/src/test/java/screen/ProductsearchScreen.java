package screen;

import test.BaseTest;

public class ProductsearchScreen extends BaseTest{
	
	
	public static final String Productsearch_box ="//*[@resource-id='com.flipkart.android:id/search_widget_textbox']";
	public static final String Productsearch_field ="//*[@text='Search for Products, Brands and More']";
	public static final String Product_searchname ="//*[@text='bose sport earbuds']";
	public static final String Product_resultname ="//*[@text='Bose Sport Earbuds Bluetooth Headset']";
	public static final String Product_detailslink ="//*[@text='All Details']";
	public static final String Product_name ="//*[@text='Bose Sport Earbuds Bluetooth Headset (Glacier White, True Wireless)']";

}
