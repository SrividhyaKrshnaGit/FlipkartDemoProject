package screen;

import test.BaseTest;

public class ProducttocartScreen extends BaseTest{
	
	public static final String Product_addtocart ="//*[@text='ADD TO CART']";
	public static final String Product_gotocart ="//*[@text='GO TO CART']";
	public static final String Product_resultname ="//*[@text='Bose Sport Earbuds Bluetooth Headset']";


	
}
