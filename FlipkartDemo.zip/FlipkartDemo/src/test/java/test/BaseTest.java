package test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Properties;
import org.apache.commons.codec.binary.Base64;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class BaseTest {
	private int port;
	private String host;
	protected static AppiumDriver<MobileElement> driver = null;
	protected static RemoteWebDriver webDriver = null;
	static DesiredCapabilities dc = new DesiredCapabilities();
	public String Testcaseid = null;
	protected static ExtentTest test;
	public String className = null;
	private static FileInputStream fileInputStream;
	private static XSSFWorkbook workbook;
	private static XSSFSheet sheet;
	private static Cell cell;
    private static String userDirectory = System.getProperty("user.dir");	
	protected static String file=userDirectory + "\\DataInput\\TestData.xlsx";
	
	// Time configuration for extent report
	LocalTime t = LocalTime.now();
	LocalDate d = LocalDate.now();
	int hours = t.getHour();
	int minutes = t.getMinute();
	public static ExtentReports report = new ExtentReports(userDirectory + "\\Reports\\FlipkartReport.html",
			true);

	@BeforeClass
	public void appiumConfiguration() throws Exception {
		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setCapability("deviceName", "SamsungGalaxyS9");
		caps.setCapability("udid", "4b34564331423598"); 
		caps.setCapability("platformName", "Android");
		caps.setCapability("platformVersion", "10");
		caps.setCapability("appPackage", "com.flipkart.android");
		caps.setCapability("appActivity", "com.flipkart.android.activity.HomeFragmentHolderActivity");
		caps.setCapability("noReset", "true");

		// Instantiate Appium Driver
		driver = new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"), caps);

	}

	@BeforeMethod
	public void setUp(Method method) {
		Testcaseid = method.getName();
		System.out.println("TestName:" + Testcaseid);
		System.out.println("Android device found...");
		test = report.startTest(Testcaseid);
	}

	@AfterClass
	public void end() {
		report.endTest(test);
		report.flush();
	}
	
	
	@AfterTest
	public void removeAndroidapp() {
		System.out.println("Unistalling Flipkart application...");
		driver.removeApp("com.flipkart.android");
		System.out.println("Flipkart application uninstalled successfully");
	}
	
	

	public void btnClick(String xpath, String button) throws IOException {
		boolean isPresent = false;
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
			driver.findElementByXPath(xpath).click();
			System.out.println(xpath + " clicked");
			isPresent = true;
			Thread.sleep(1000);
			test.log(LogStatus.PASS, button + " button has been clicked"+ test.addScreenCapture(BaseTest.captureScreen()));
		} catch (Exception e) {
			isPresent = false;
			System.out.println(xpath + " not found");
			test.log(LogStatus.FAIL, button + "Element not found" + test.addScreenCapture(BaseTest.captureScreen()));
		}
	}

	public void findElement(String xpath, String button) throws IOException {
		boolean isPresent = false;
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
			driver.findElementByXPath(xpath);
			System.out.println(button + " found");
			isPresent = true;
			test.log(LogStatus.PASS, button + " element has been found "+ test.addScreenCapture(BaseTest.captureScreen()));
		} catch (Exception e) {
			isPresent = false;
			System.out.println(button + " not found");
			test.log(LogStatus.FAIL, button + " element not found"+ test.addScreenCapture(BaseTest.captureScreen()));
		}
	}

	public void enterText(String xpath, String input, String button) throws IOException {
		String[] namesplit = xpath.split("'");
		String sname = namesplit[namesplit.length - 2];
		boolean isPresent = false;
		try {
			WebDriverWait wait = new WebDriverWait(driver, 15);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpath)));
			driver.findElementByXPath(xpath).sendKeys(input);
			isPresent = true;
			System.out.println(xpath + " found, Entered values: " + input);
			test.log(LogStatus.PASS, "User input entered in " + button, "Entered User input: " + input+ test.addScreenCapture(BaseTest.captureScreen()));
		} catch (Exception e) {
			System.out.println(xpath + " not found");
			test.log(LogStatus.FAIL, "Text not Entered in " + button, "Entered product name failed: " + input+ test.addScreenCapture(BaseTest.captureScreen()));
		}
	}

	public void getTextFromElement(String xpath, String expected) throws InterruptedException
	{
	try {
	boolean isPresent = false;
	WebDriverWait wait=new WebDriverWait(driver, 15);
	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpath)));
	WebElement web = driver.findElementByXPath(xpath);
	String text= web.getText();
	isPresent = true;
	try {
	Assert.assertEquals(text, expected);
	test.log(LogStatus.PASS, text+ " and " +expected+" product details are compared and matched"+ test.addScreenCapture(BaseTest.captureScreen()));
	}
	catch(Exception e) {
	test.log(LogStatus.PASS, text+ " and " +expected+"  product details are not matched"+ test.addScreenCapture(BaseTest.captureScreen()));
	}
	}
	catch(Exception e) {
	System.out.println("Text not found");
	test.log(LogStatus.FAIL, xpath+ "Not found");
	}
	}

	public static String captureScreen() {
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		String encodedBase64 = null;
		FileInputStream fileInputStreamReader = null;
		try {
			fileInputStreamReader = new FileInputStream(scrFile);
			byte[] bytes = new byte[(int) scrFile.length()];
			fileInputStreamReader.read(bytes);
			encodedBase64 = new String(Base64.encodeBase64(bytes));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return "data:image/png;base64," + encodedBase64;
	}

	public void enterTextSecure(String xpath, String input, String button) throws IOException {
		String[] namesplit = xpath.split("'");
		String sname = namesplit[namesplit.length - 2];
		boolean isPresent = false;
		try {
			WebDriverWait wait = new WebDriverWait(driver, 15);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpath)));
			driver.findElementByXPath(xpath).sendKeys(input);
			isPresent = true;
			System.out.println(xpath + " found");
			test.log(LogStatus.PASS, "Entered User input: " + button+ test.addScreenCapture(BaseTest.captureScreen()));
		} catch (Exception e) {
			System.out.println(xpath + " not found");
			test.log(LogStatus.FAIL, "Text not Entered in " + button+ test.addScreenCapture(BaseTest.captureScreen()));
		}
	}

	public static String excel(String file, int sheet, int rowNum, int cellNum) throws IOException {
		fileInputStream = new FileInputStream(file);
		workbook = new XSSFWorkbook(fileInputStream);
		cell = workbook.getSheetAt(sheet).getRow(rowNum).getCell(cellNum);
		DataFormatter dataFormatter = new DataFormatter();
		return dataFormatter.formatCellValue(cell);
	}

}
