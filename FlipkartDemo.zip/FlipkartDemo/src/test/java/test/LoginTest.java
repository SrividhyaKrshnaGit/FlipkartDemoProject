package test;

import java.io.IOException;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import screen.LoginScreen;

public class LoginTest extends BaseTest{
	
	
	
	public void applogin() throws IOException, InterruptedException
	{
		//Test starts from the application dashboard screen burger menu for Account creation. Email id used for account creation
		
		btnClick(LoginScreen.Burger_Menu,"Burger Menu");
		btnClick(LoginScreen.My_Account,"My Account");
		btnClick(LoginScreen.My_Account_EmailLogin,"User Email id");
		btnClick(LoginScreen.My_Account_Emailfield,"Email entry field");
		enterText(LoginScreen.My_Account_Emailfield,excel(file,0,1,1),"email input field");
		btnClick(LoginScreen.My_Account_Continue,"Continue");
		enterTextSecure(LoginScreen.My_Account_Passwordfield,excel(file,0,1,2),"User Password");
		btnClick(LoginScreen.My_Account_Continue,"Continue");
		test.log(LogStatus.PASS, "User login test successfully completed");







		
		
		
	}

	
	
	
	
	
	
	

}
