package test;

import java.io.IOException;

import com.relevantcodes.extentreports.LogStatus;

import screen.LoginScreen;
import screen.ProductsearchScreen;

public class ProductsearchTest extends BaseTest{
	
	public void productSearch() throws IOException, InterruptedException
	{	
		//Search for the "Bose Sport Earbuds" and navigates to product details screen
		
		btnClick(LoginScreen.My_Account_Back,"My Account Back");
		btnClick(ProductsearchScreen.Productsearch_box,"Product search box");
		enterText(ProductsearchScreen.Productsearch_field,excel(file,1,1,1),"Product name");
		btnClick(ProductsearchScreen.Product_searchname,"User input: Bose Sport Earbuds first record");
		btnClick(ProductsearchScreen.Product_resultname,"User input: Bose Sport Earbuds product details");
		test.log(LogStatus.PASS, "Product search test successfully completed");

		
	}

	
	
	
	
	
	
	

}
