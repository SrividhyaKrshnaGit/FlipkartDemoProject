package test;

import java.io.IOException;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import screen.ProductsearchScreen;
import screen.ProducttocartScreen;

public class ProducttocartTest extends BaseTest{
	
@Test
	
	public void addToCart() throws IOException, InterruptedException
	{
		//Compare user input with the product in details screen for successful test completion executing test report
	
		btnClick(ProducttocartScreen.Product_addtocart,"Add to cart");
		getTextFromElement(ProductsearchScreen.Product_name,"Bose Sport Earbuds Bluetooth Headset (Glacier White, True Wireless)");
		btnClick(ProducttocartScreen.Product_gotocart,"Go to cart");
		test.log(LogStatus.PASS, "The Flipkart demo test is completed and extent report is generated successfully");
	}


}
